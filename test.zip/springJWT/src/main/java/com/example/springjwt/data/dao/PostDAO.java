package com.example.springjwt.data.dao;

import com.example.springjwt.data.entity.AuthenEntity;
import com.example.springjwt.data.entity.PostEntity;
import com.example.springjwt.data.repository.AuthenEntityRepository;
import com.example.springjwt.data.repository.PostEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class PostDAO {
    private final PostEntityRepository postEntityRepository;
    private final AuthenEntityRepository authenEntityRepository;

    public PostEntity savePost(String title, String content,Integer userid) {
        AuthenEntity authenEntity = this.authenEntityRepository.findById(userid).get();

        PostEntity resPost = PostEntity.builder()

                .title(title)
                .content(content)
                .userid(authenEntity)
                .build();

        this.postEntityRepository.save(resPost);
        return resPost;

    }
}
