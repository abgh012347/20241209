package com.example.springjwt.data.repository;

import com.example.springjwt.data.entity.AuthenEntity;
import com.example.springjwt.data.entity.PostEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostEntityRepository extends JpaRepository<PostEntity, Integer>{
}
