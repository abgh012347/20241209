package com.example.springjwt.data.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="authentbl")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuthenEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer id;
    @Column(unique=true, nullable=false)
    private String username;
    @Column(nullable=false)
    private String password;
    private String role;
    @OneToMany(mappedBy = "userid")
    private List<PostEntity> posts = new ArrayList<>();
}
