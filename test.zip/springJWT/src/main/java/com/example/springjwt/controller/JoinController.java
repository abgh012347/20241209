package com.example.springjwt.controller;

import com.example.springjwt.data.dto.AuthenDTO;
import com.example.springjwt.data.dto.PostDTO;
import com.example.springjwt.data.entity.PostEntity;
import com.example.springjwt.service.AuthenService;
import com.example.springjwt.service.JoinService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class JoinController {
    private final JoinService joinService;
    private final AuthenService authenService;

    @Transactional
    @PostMapping(value="/join")
    public ResponseEntity<String> join(@RequestBody AuthenDTO authenDTO) {
        if(this.joinService.join(authenDTO)) {
            return ResponseEntity.status(HttpStatus.CREATED).body("가입성공");
        }

        return ResponseEntity.status(HttpStatus.CONFLICT).body("이미 있는 아이디 입니다.");
    }
    @Transactional
    @GetMapping(value="/admin")
    public ResponseEntity<String> admin() {
        return ResponseEntity.status(HttpStatus.OK).body("관리자입니다");
    }
//    @GetMapping(value = "/search")
//    public ResponseEntity<List<AuthenDTO>> searchUserInfo() {
//        List<AuthenDTO> authenDTOList=this.authenService.searchUserInfo();
//        return ResponseEntity.ok(authenDTOList);
//    };
    @Transactional
    @PostMapping(value="/postadd")
    public ResponseEntity<String> postadd(@RequestBody PostEntity postEntity) {
        this.joinService.postadd(postEntity);
            return ResponseEntity.status(HttpStatus.CREATED).body("가입성공");

    }

}
