package com.example.springjwt.controller;

import com.example.springjwt.jwt.JwtUtil;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class ReissueController {
    private final JwtUtil jwtUtil;
    @PostMapping(value = "/reissue")
    public ResponseEntity<String> reissue(HttpServletRequest request, HttpServletResponse response) {
        String refresh=null;
        Cookie[] cookies = request.getCookies();
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("refresh")) {
                refresh = cookie.getValue();
                break;
            }
        }
        if(refresh==null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("refresh 토큰 null");
        }
        try{
            this.jwtUtil.isExpired(refresh);
        }
        catch (ExpiredJwtException ex){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("refresh토큰 유효기간 만료");
        }
        String category = this.jwtUtil.getCategory(refresh);
        if(!category.equals("refresh")){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("refresh 아닌뎁숑");
        }

        String username = jwtUtil.getUsername(refresh);
        String role = jwtUtil.getRole(refresh);

        String newAccessToken = this.jwtUtil.CreateJWT("access",username,role,5000L);
        response.addHeader("Authorization","Bearer "+newAccessToken);

        return ResponseEntity.status(HttpStatus.OK).body("새토큰 발급 성공");
    }
}
