import apiClient from "./api/axiosInstance";
import {useDispatch, useSelector} from "react-redux";
import {PostInfo} from "./store";

export default function Readpost() {
    const postInfoList = useSelector((state) => state.userInfo.postList);
    const dispatch = useDispatch();
    const handleLink = async (e) => {
        let paramData = null;

        try {
            const response = await apiClient.get("/readpost", {

            });
            response.data.map((t) => dispatch(PostInfo(t)));

        } catch (error) {
            alert("오류발생");

        }
    };
    const list = postInfoList.map((t) => (
        <div key={t.id}>
            <hr />
            <p>제목 : {t.title}</p>
            <p>내용 : {t.content}</p>


            {/* {"/update_product/" + t.id} */}
            <hr />
        </div>
    ));

    return(
        <>
            <form onLoad={handleLink}>
                {list}
            </form>
        </>

)
}