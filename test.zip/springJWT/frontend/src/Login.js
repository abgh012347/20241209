import {useState} from "react";
import axios from 'axios';
import {useSelector, useDispatch} from "react-redux";
import {login, saveCsrfToken, saveJwtToken, userid} from "./store";
import apiClient from "./api/axiosInstance";
import {Link, useNavigate} from "react-router-dom";

export default function Login() {
    const dispatch=useDispatch();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const [message, setMessage] = useState("");
    const jwtToken=useSelector(state=>state.userInfo.jwtToken);

    const handleJoin = async (e) => {
        e.preventDefault();
        try {
            const response = await apiClient.post("/join",
                {username, password},
             );
            setMessage(response.data);
        } catch (error) {
            console.log(error);
            setMessage(error.message)
        }
    }

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await apiClient.post("/login",
                new URLSearchParams({username, password}),
                {
                    withCredentials:true,
                }
                );

            const token=response.headers["authorization"];
            console.log("토큰:", token);
            await dispatch(userid(username));
            await dispatch(saveJwtToken(token));
            console.log("jwt토큰:",token);
            await dispatch(login());
        } catch(error) {
            console.log(error);
            setMessage("로그인 실패")
        }
    };


    return (
        <>
            <form>

                <input type="text" placeholder="아이디" value={username}
                       onChange={(e) => setUsername(e.target.value)}/>

                <input type="password" placeholder="비밀번호" value={password}
                       onChange={(e) => setPassword(e.target.value)}/>

                <button type="button" name="login" onClick={handleLogin}>로그인</button>
                <button type="button" name="join" onClick={handleJoin}>가입</button>
                <Link to="/readpost">게시글 목록</Link>
            </form>
            <h2>{message}</h2>
        </>
    )
}