import {createSlice, configureStore} from "@reduxjs/toolkit";
const userInfoSlice=createSlice({
    name: "userInfo",
    initialState:{
        jwtToken:null,
        userid:null,
        loginFlag:false,
        postList: [],
    },
    reducers:{
        saveJwtToken:(state, action)=>{
            state.jwtToken=action.payload;
        },
        login:(state)=>{
            state.loginFlag=true;
        },
        logout:(state)=>{
            state.loginFlag=false;
            state.jwtToken=null;
        },
        userid:(state,action)=>{
            state.userid = action.payload;
        },
        PostInfo: (state, action) => {
            state.buyInfoList.push(action.payload);
            state.buy_count++;
        },
    }
});
const store=configureStore({
    reducer:{
        userInfo:userInfoSlice.reducer,
    }
});
export const {saveJwtToken, login, logout,PostInfo,userid}=userInfoSlice.actions;
export default  store;