import {useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import axios from "axios";
import {logout} from "./store";
import apiClient from "./api/axiosInstance";

export default function TestConponents() {
    const [message, setMessage]=useState("");
    const jwtToken=useSelector(state=>state.userInfo.jwtToken);
    const dispatch = useDispatch();
    const [p_title,setPTitle] = useState();
    const [p_content,setPContent] = useState();
    const userid = useSelector(state=>state.userInfo.userid);


    const handleLogout=async (e)=>{
        try{
            dispatch(logout());
            console.log(jwtToken);
            setMessage("로그아웃 되었습니다.");
        }catch(error){
            console.log(error);
            console.log("로그아웃 오류");
        }

    };
    const handleAdminClick=async (e)=>{
        e.preventDefault();
        try{
            const response=await apiClient.get("/admin");
            if(response == undefined){
                setMessage("관리자가 아닙니다.");
                return;
            }
            setMessage(response.data);

        }catch(error){
            if(error.response.status === 401){
                setMessage(error.response.data.message);
            }
            else if(error.response.status === 403) {
                setMessage(error.response.data);
            }
            else{
                setMessage(error.message);
                console.log(error);
            }

        }

    }
    const handlePost = async (e) => {
        e.preventDefault();
        try{
            setMessage("");

        }
        catch (error) {

        }

    };
    const handleReadPost = async (e) => {
        e.preventDefault();
        try{
            setMessage("");

        }
        catch (error) {

        }

    };

    return (
        <>
            <button onClick={handleLogout}>LOGOUT</button>
            <button onClick={handleAdminClick}>ADMIN</button>
            <h1>{message}</h1>

            제목 : <input type="text"
                        defaultValue=""
                        onChange={(e) => {
                            setPTitle(e.target.value);
                        }}></input>
            <br/>
            내용 : <input type="text"
                        defaultValue=""
                        onChange={(e) => {
                            setPContent(e.target.value);
                        }}></input>
            <br/>
            <button  onClick={async (e) => {
                try {
                    {
                        e.preventDefault();
                        const data = { title: p_title, content: p_content , userid:userid};
                        const responce = await apiClient.post(
                            "http://localhost:8080/postadd",
                            data,
                            {
                                headers: {

                                },
                                timeout: 10000000,
                            }
                        );
                        // dispatch(createProduct(responce.data));

                        // dispatch(createProduct({ g_name, g_price }));
                        // navigate("/");
                    }
                } catch (error) {
                    if (error.code === "ECONNABORTED") {
                        console.error("요청시간 초과");
                    } else if (error.responce) {
                        console.error("서버 에러 : ");
                        console.error("상태 코드 : ", error.responce.status);
                        console.error("응답 데이터 : ", error.responce.data);
                    } else if (error.request) {
                        console.error("요청 실패 : 서버에 응답이 없습니다.");
                    }
                    console.error(error.message);
                }
            }}
            >
                SAVE
            </button>
        </>
    )
}