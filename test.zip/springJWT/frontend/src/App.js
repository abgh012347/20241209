import './App.css';
import {useEffect} from "react";
import TestConponents from "./TestConponents";
import Login from './Login';
import axios from "axios";
import {useDispatch, useSelector} from "react-redux";
import {saveCsrfToken} from "./store";
import {BrowserRouter, Route, Routes} from "react-router-dom";
import Readpost from "./Readpost";

function App() {
  const loginFlag=useSelector(state=>state.userInfo.loginFlag);
  return (
    <>
      {!loginFlag && <Login></Login>}
      {loginFlag && <TestConponents/>}
        <Routes>
          <Route path="/readpost" element={<Readpost/>}></Route>
        </Routes>


    </>
  );
}

export default App;
